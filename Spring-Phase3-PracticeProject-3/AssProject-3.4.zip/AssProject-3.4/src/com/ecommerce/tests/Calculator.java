package com.ecommerce.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Calculator {

    public int add(int a, int b) {
        return a + b;
    }


}
