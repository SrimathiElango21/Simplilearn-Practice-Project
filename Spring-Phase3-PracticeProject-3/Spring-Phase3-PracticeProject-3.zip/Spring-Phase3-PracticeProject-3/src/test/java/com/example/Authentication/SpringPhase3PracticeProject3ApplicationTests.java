package com.example.Authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPhase3PracticeProject3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
